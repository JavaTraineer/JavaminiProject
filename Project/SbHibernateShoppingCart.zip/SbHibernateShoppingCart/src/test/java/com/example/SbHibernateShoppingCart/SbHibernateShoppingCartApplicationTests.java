package com.example.SbHibernateShoppingCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbHibernateShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
